import { useEffect, useState } from "react";

const PROFILE_API = "http://localhost:5000/api/auth/profile";
const ME_API = "http://localhost:5000/api/auth/me";

function Profile({ user, onProfileUpdated }) {
  const [profile, setProfile] = useState({
    fullName: user?.fullName || "",
    email: user?.email || "",
    profilePhoto: user?.profilePhoto || "",
  });

  const [preview, setPreview] = useState(
    user?.profilePhoto || ""
  );

  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingProfile, setLoadingProfile] = useState(true);

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // =====================================================
  // LOAD CURRENT PROFILE
  // =====================================================
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const token = localStorage.getItem("token");

        if (!token) {
          setError("You are not logged in.");
          return;
        }

        const response = await fetch(ME_API, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
          throw new Error(
            data.message || "Failed to load profile."
          );
        }

        const currentUser = {
          id: data.data._id || data.data.id,
          fullName: data.data.fullName || "",
          email: data.data.email || "",
          profilePhoto: data.data.profilePhoto || "",
        };

        setProfile(currentUser);
        setPreview(currentUser.profilePhoto);

        // Keep localStorage synchronized
        localStorage.setItem(
          "user",
          JSON.stringify(currentUser)
        );

        // Update App.jsx user state
        if (onProfileUpdated) {
          onProfileUpdated(currentUser);
        }
      } catch (error) {
        console.error(
          "Profile loading error:",
          error
        );

        setError(
          error.message ||
            "Unable to load your profile."
        );
      } finally {
        setLoadingProfile(false);
      }
    };

    fetchProfile();

    // IMPORTANT:
    // Load profile only once when this page opens.
  }, []);

  // =====================================================
  // HANDLE FULL NAME CHANGE
  // =====================================================
  const handleChange = (e) => {
    const { name, value } = e.target;

    setProfile((previous) => ({
      ...previous,
      [name]: value,
    }));

    setError("");
    setSuccess("");
  };

  // =====================================================
  // HANDLE PROFILE PHOTO
  // =====================================================
  const handlePhotoChange = (e) => {
    const file = e.target.files?.[0];

    if (!file) {
      return;
    }

    // Check file type
    if (!file.type.startsWith("image/")) {
      setError(
        "Please select a valid image file."
      );
      return;
    }

    // Maximum 2 MB
    if (file.size > 2 * 1024 * 1024) {
      setError(
        "Profile photo must be smaller than 2 MB."
      );
      return;
    }

    setError("");
    setSuccess("");

    const reader = new FileReader();

    reader.onloadend = () => {
      const imageData = reader.result;

      // Update preview immediately
      setPreview(imageData);

      // Store image data in profile state
      setProfile((previous) => ({
        ...previous,
        profilePhoto: imageData,
      }));
    };

    reader.onerror = () => {
      setError(
        "Failed to read the selected image."
      );
    };

    reader.readAsDataURL(file);
  };

  // =====================================================
  // SAVE PROFILE
  // =====================================================
  const handleSave = async (e) => {
    e.preventDefault();

    setError("");
    setSuccess("");

    // Validate name
    if (!profile.fullName.trim()) {
      setError(
        "Please enter your full name."
      );
      return;
    }

    try {
      setLoading(true);

      const token = localStorage.getItem("token");

      if (!token) {
        setError("You are not logged in.");
        return;
      }

      const response = await fetch(PROFILE_API, {
        method: "PUT",

        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },

        body: JSON.stringify({
          fullName: profile.fullName.trim(),
          profilePhoto:
            profile.profilePhoto || "",
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(
          data.message ||
            "Failed to update profile."
        );
      }

      // Create updated user object
      const updatedUser = {
        id: data.data._id || data.data.id,
        fullName: data.data.fullName || "",
        email: data.data.email || "",
        profilePhoto:
          data.data.profilePhoto || "",
      };

      // =================================================
      // UPDATE PROFILE PAGE
      // =================================================
      setProfile(updatedUser);

      // Update photo preview
      setPreview(
        updatedUser.profilePhoto
      );

      // =================================================
      // UPDATE LOCAL STORAGE
      // =================================================
      localStorage.setItem(
        "user",
        JSON.stringify(updatedUser)
      );

      // =================================================
      // UPDATE APP.JSX USER STATE
      // =================================================
      if (onProfileUpdated) {
        onProfileUpdated(updatedUser);
      }

      // Show success message
      setSuccess(
        "Profile updated successfully!"
      );

      // Exit edit mode
      setIsEditing(false);
    } catch (error) {
      console.error(
        "Profile update error:",
        error
      );

      setError(
        error.message ||
          "Unable to update your profile."
      );
    } finally {
      setLoading(false);
    }
  };

  // =====================================================
  // CANCEL EDITING
  // =====================================================
  const handleCancel = () => {
    const savedUser = JSON.parse(
      localStorage.getItem("user") || "{}"
    );

    const originalProfile = {
      id:
        savedUser._id ||
        savedUser.id ||
        "",
      fullName:
        savedUser.fullName || "",
      email:
        savedUser.email || "",
      profilePhoto:
        savedUser.profilePhoto || "",
    };

    setProfile(originalProfile);

    setPreview(
      originalProfile.profilePhoto
    );

    setError("");
    setSuccess("");

    setIsEditing(false);
  };

  // =====================================================
  // LOADING
  // =====================================================
  if (loadingProfile) {
    return (
      <div className="profile-page">
        <div className="profile-loading">
          Loading profile...
        </div>
      </div>
    );
  }

  // =====================================================
  // PROFILE PAGE
  // =====================================================
  return (
    <div className="profile-page">

      {/* ================================================
          PAGE HEADER
      ================================================= */}
      <div className="profile-page-header">

        <div>
          <div className="page-label">
            ACCOUNT
          </div>

          <h1>Profile</h1>

          <p>
            View and manage your personal
            information
          </p>
        </div>

        {/* Edit Button */}
        {!isEditing && (
          <button
            type="button"
            className="edit-profile-button"
            onClick={() => {
              setError("");
              setSuccess("");
              setIsEditing(true);
            }}
          >
            ✏️ Edit Profile
          </button>
        )}

      </div>

      {/* ================================================
          PROFILE CARD
      ================================================= */}
      <div className="profile-card">

        {/* ==============================================
            PROFILE PHOTO
        =============================================== */}
        <div className="profile-photo-large">

          {preview ? (
            <img
              src={preview}
              alt="Profile"
            />
          ) : (
            <span>
              {profile.fullName
                ? profile.fullName
                    .charAt(0)
                    .toUpperCase()
                : "U"}
            </span>
          )}

        </div>

        {/* ==============================================
            VIEW MODE
        =============================================== */}
        {!isEditing ? (
          <div className="profile-information">

            {/* Full Name */}
            <div className="profile-field">
              <label>
                Full Name
              </label>

              <div className="profile-value">
                {profile.fullName ||
                  "Not provided"}
              </div>
            </div>

            {/* Email */}
            <div className="profile-field">
              <label>
                Email Address
              </label>

              <div className="profile-value">
                {profile.email ||
                  "Not provided"}
              </div>
            </div>

            {/* Photo Status */}
            <div className="profile-photo-status">
              <span>📷</span>

              {profile.profilePhoto
                ? "Profile photo uploaded"
                : "No profile photo uploaded"}
            </div>

          </div>
        ) : (

          /* ============================================
             EDIT MODE
          ============================================= */
          <form
            className="profile-edit-form"
            onSubmit={handleSave}
          >

            {/* ==========================================
                CHANGE PHOTO
            =========================================== */}
            <div className="profile-upload-area">

              <label
                htmlFor="profile-photo-edit"
                className="profile-change-photo"
              >
                Change Profile Photo
              </label>

              <input
                id="profile-photo-edit"
                type="file"
                accept="image/*"
                onChange={handlePhotoChange}
                className="profile-file-input"
              />

              <small>
                JPG, PNG or other image formats
                {" "}•{" "}
                Maximum 2 MB
              </small>

            </div>

            {/* ==========================================
                FULL NAME
            =========================================== */}
            <div className="profile-form-group">

              <label
                htmlFor="profile-full-name"
              >
                Full Name
              </label>

              <input
                id="profile-full-name"
                type="text"
                name="fullName"
                value={profile.fullName}
                onChange={handleChange}
                placeholder="Enter your full name"
              />

            </div>

            {/* ==========================================
                EMAIL
            =========================================== */}
            <div className="profile-form-group">

              <label
                htmlFor="profile-email"
              >
                Email Address
              </label>

              <input
                id="profile-email"
                type="email"
                value={profile.email}
                disabled
              />

              <small>
                Email address cannot be changed
                here.
              </small>

            </div>

            {/* ==========================================
                ERROR MESSAGE
            =========================================== */}
            {error && (
              <div className="profile-error">
                ⚠️ {error}
              </div>
            )}

            {/* ==========================================
                SUCCESS MESSAGE
            =========================================== */}
            {success && (
              <div className="profile-success">
                ✓ {success}
              </div>
            )}

            {/* ==========================================
                ACTION BUTTONS
            =========================================== */}
            <div className="profile-form-actions">

              {/* Cancel */}
              <button
                type="button"
                className="profile-cancel-button"
                onClick={handleCancel}
                disabled={loading}
              >
                Cancel
              </button>

              {/* Save */}
              <button
                type="submit"
                className="profile-save-button"
                disabled={loading}
              >
                {loading
                  ? "Saving..."
                  : "Save Changes"}
              </button>

            </div>

          </form>
        )}

      </div>

      {/* ================================================
          SUCCESS MESSAGE OUTSIDE EDIT MODE
      ================================================= */}
      {!isEditing && success && (
        <div className="profile-success profile-message">
          ✓ {success}
        </div>
      )}

      {/* ================================================
          ERROR MESSAGE OUTSIDE EDIT MODE
      ================================================= */}
      {!isEditing && error && (
        <div className="profile-error profile-message">
          ⚠️ {error}
        </div>
      )}

    </div>
  );
}

export default Profile;
