import React, { useEffect, useMemo, useState } from "react";

const INCOME_API = "http://localhost:5000/api/income";
const EXPENSE_API = "http://localhost:5000/api/expenses";

function Dashboard({ onNavigateToProfile }) {
  const [income, setIncome] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [period, setPeriod] = useState("30");

  const getToken = () => localStorage.getItem("token");

  const handleUnauthorized = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.reload();
  };

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        setError("");

        const token = getToken();

        if (!token) {
          setError("Please login again.");
          return;
        }

        const headers = {
          Authorization: `Bearer ${token}`,
        };

        const [ir, er] = await Promise.all([
          fetch(INCOME_API, { headers }),
          fetch(EXPENSE_API, { headers }),
        ]);

        if (ir.status === 401 || er.status === 401) {
          handleUnauthorized();
          return;
        }

        if (!ir.ok || !er.ok) {
          throw new Error("Failed to load dashboard data");
        }

        const incomeResult = await ir.json();
        const expenseResult = await er.json();

        if (!incomeResult.success) {
          throw new Error(
            incomeResult.message || "Failed to load income"
          );
        }

        if (!expenseResult.success) {
          throw new Error(
            expenseResult.message || "Failed to load expenses"
          );
        }

        setIncome(incomeResult.data || []);
        setExpenses(expenseResult.data || []);
      } catch (err) {
        console.error("Dashboard error:", err);

        setError(
          err.message ||
            "Unable to load dashboard data from the server."
        );
      } finally {
        setLoading(false);
      }
    };

    load();
  }, []);

  const totals = useMemo(() => {
    const i = income.reduce(
      (s, x) => s + Number(x.amount || 0),
      0
    );

    const e = expenses.reduce(
      (s, x) => s + Number(x.amount || 0),
      0
    );

    return {
      income: i,
      expenses: e,
      balance: i - e,
      savings:
        i > 0
          ? Math.max(0, ((i - e) / i) * 100)
          : 0,
    };
  }, [income, expenses]);

  const filteredExpenses = useMemo(() => {
    const cutoff = new Date();

    cutoff.setHours(0, 0, 0, 0);
    cutoff.setDate(
      cutoff.getDate() - Number(period) + 1
    );

    return expenses.filter((x) => {
      const d = new Date(x.date);

      return (
        !Number.isNaN(d.getTime()) &&
        d >= cutoff
      );
    });
  }, [expenses, period]);

  const transactions = useMemo(() => {
    return [
      ...income.map((x) => ({
        id: `i-${x._id || x.id}`,
        name:
          x.source ||
          x.title ||
          "Income",
        date: x.date,
        amount: Number(x.amount || 0),
        type: "income",
      })),

      ...expenses.map((x) => ({
        id: `e-${x._id || x.id}`,
        name:
          x.title ||
          x.category ||
          "Expense",
        date: x.date,
        amount: Number(x.amount || 0),
        type: "expense",
      })),
    ]
      .sort(
        (a, b) =>
          new Date(b.date) -
          new Date(a.date)
      )
      .slice(0, 6);
  }, [income, expenses]);

  const categoryData = useMemo(() => {
    const groups = {};

    filteredExpenses.forEach((x) => {
      const key =
        x.category ||
        x.title ||
        "Other";

      groups[key] =
        (groups[key] || 0) +
        Number(x.amount || 0);
    });

    const total = Object.values(groups).reduce(
      (s, x) => s + x,
      0
    );

    return Object.entries(groups)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, amount]) => ({
        name,
        amount,
        percent: total
          ? (amount / total) * 100
          : 0,
      }));
  }, [filteredExpenses]);

  const chartData = useMemo(() => {
    const groups = {};

    filteredExpenses.forEach((x) => {
      const d = new Date(x.date);

      if (!Number.isNaN(d.getTime())) {
        const key = d
          .toISOString()
          .slice(0, 10);

        groups[key] =
          (groups[key] || 0) +
          Number(x.amount || 0);
      }
    });

    return Object.entries(groups)
      .sort(
        ([a], [b]) =>
          new Date(a) - new Date(b)
      )
      .slice(-12)
      .map(([date, amount]) => ({
        date,
        amount,
      }));
  }, [filteredExpenses]);

  const formatAmount = (amount) =>
    new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 0,
    }).format(amount);

  const formatDate = (date) =>
    date
      ? new Date(date).toLocaleDateString(
          "en-US",
          {
            month: "short",
            day: "numeric",
            year: "numeric",
          }
        )
      : "-";

  const user = useMemo(() => {
    try {
      return JSON.parse(
        localStorage.getItem("user") || "{}"
      );
    } catch {
      return {};
    }
  }, []);

  const firstName = user.fullName
    ? user.fullName
        .trim()
        .split(/\s+/)[0]
    : "there";

  const max = chartData.length
    ? Math.max(
        ...chartData.map((x) => x.amount),
        100
      )
    : 100;

  const W = 900;
  const H = 240;

  const points = chartData
    .map(
      (x, i) =>
        `${
          chartData.length === 1
            ? W / 2
            : (i /
                (chartData.length - 1)) *
              W
        },${
          H -
          (x.amount / max) * H
        }`
    )
    .join(" ");

  const budget = totals.income
    ? Math.min(
        100,
        (totals.expenses /
          totals.income) *
          100
      )
    : 0;

  return (
    <section className="dashboard-page redesigned-dashboard">

      {/* TOP BAR */}
      <header className="dashboard-topbar">

        {/* Dashboard Brand */}
        <div className="dashboard-topbar-brand">
          <div className="dashboard-topbar-brand-mark">💰</div>
          <div>
            <strong>Expense Tracker</strong>
            <small>Smart money management</small>
          </div>
        </div>

        {/* Profile Button */}
        <div className="dashboard-topbar-actions">

          <button
            type="button"
            className="dashboard-profile-mini dashboard-profile-button"
            onClick={onNavigateToProfile}
            aria-label="Open profile"
          >

            <div className="dashboard-mini-avatar">
              {user.profilePhoto ? (
                <img
                  src={user.profilePhoto}
                  alt="Profile"
                />
              ) : (
                (firstName[0] || "U").toUpperCase()
              )}
            </div>

            <div className="dashboard-profile-text">
              <strong>
                {user.fullName || "User"}
              </strong>

              <small>
                Personal account
              </small>
            </div>

          </button>

        </div>

      </header>

      {error && (
        <div className="server-error">
          {error}
        </div>
      )}

      {/* WELCOME HERO */}
      <div className="dashboard-welcome">

        <div>
          <p className="dashboard-kicker">
            FINANCIAL OVERVIEW
          </p>

          <h1>
            Good to see you, {firstName}!
          </h1>

          <p>
            Keep your finances organized
            and make every dollar count.
          </p>
        </div>

        <div
          className="dashboard-hero-art"
          aria-hidden="true"
        >
          <div className="hero-coin hero-coin-one">
            $
          </div>

          <div className="hero-coin hero-coin-two">
            $
          </div>

          <div className="hero-plant">
            <span />
            <span />
            <span />
            <div />
          </div>
        </div>

      </div>

      {/* SUMMARY CARDS */}
      <div className="summary-grid redesigned-summary-grid">

        <article className="summary-card dashboard-stat-card">

          <div className="dashboard-stat-icon balance-stat">
            ◉
          </div>

          <div>
            <span>Total Balance</span>

            <strong>
              {loading
                ? "$0"
                : formatAmount(
                    totals.balance
                  )}
            </strong>

            <small>
              {totals.balance >= 0
                ? "Healthy balance"
                : "Review spending"}
            </small>
          </div>

        </article>

        <article className="summary-card dashboard-stat-card">

          <div className="dashboard-stat-icon income-stat">
            ↗
          </div>

          <div>
            <span>Total Income</span>

            <strong>
              {loading
                ? "$0"
                : formatAmount(
                    totals.income
                  )}
            </strong>

            <small>
              All recorded income
            </small>
          </div>

        </article>

        <article className="summary-card dashboard-stat-card">

          <div className="dashboard-stat-icon expense-stat">
            ↘
          </div>

          <div>
            <span>Total Expenses</span>

            <strong>
              {loading
                ? "$0"
                : formatAmount(
                    totals.expenses
                  )}
            </strong>

            <small>
              All recorded spending
            </small>
          </div>

        </article>

        <article className="summary-card dashboard-stat-card">

          <div className="dashboard-stat-icon savings-stat">
            ✦
          </div>

          <div>
            <span>Savings Rate</span>

            <strong>
              {loading
                ? "0%"
                : `${Math.round(
                    totals.savings
                  )}%`}
            </strong>

            <small>
              Income kept after expenses
            </small>
          </div>

        </article>

      </div>

      {/* MAIN DASHBOARD */}
      <div className="dashboard-main-grid">

        {/* EXPENSE OVERVIEW */}
        <article className="dashboard-panel expense-overview-panel">

          <div className="dashboard-panel-heading">

            <div>

              <p className="panel-label">
                SPENDING TREND
              </p>

              <h2>
                Expense Overview
              </h2>

              <p>
                See how your spending changes
                over time.
              </p>

            </div>

            <select
              className="period-select"
              value={period}
              onChange={(e) =>
                setPeriod(e.target.value)
              }
            >
              <option value="7">
                Last 7 days
              </option>

              <option value="30">
                Last 30 days
              </option>

              <option value="90">
                Last 3 months
              </option>
            </select>

          </div>

          <div className="chart-wrapper redesigned-chart-wrapper">

            <div className="chart-labels">
              <span>
                ${max.toLocaleString()}
              </span>

              <span>
                $
                {Math.round(
                  max * 0.75
                ).toLocaleString()}
              </span>

              <span>
                $
                {Math.round(
                  max * 0.5
                ).toLocaleString()}
              </span>

              <span>
                $
                {Math.round(
                  max * 0.25
                ).toLocaleString()}
              </span>

              <span>$0</span>
            </div>

            {chartData.length === 0 ? (

              <div className="empty-chart">

                <div className="empty-chart-icon">
                  ⌁
                </div>

                <p>
                  No expense data for
                  this period.
                </p>

                <span>
                  Add expenses to see
                  your spending trend.
                </span>

              </div>

            ) : (

              <svg
                className="expense-chart"
                viewBox={`0 0 ${W} ${H}`}
                preserveAspectRatio="none"
                role="img"
                aria-label="Expense trend chart"
              >

                <defs>
                  <linearGradient
                    id="dashboardAreaFill"
                    x1="0"
                    y1="0"
                    x2="0"
                    y2="1"
                  >
                    <stop
                      offset="0%"
                      stopColor="#10B981"
                      stopOpacity=".28"
                    />

                    <stop
                      offset="100%"
                      stopColor="#10B981"
                      stopOpacity=".02"
                    />
                  </linearGradient>
                </defs>

                {[0, 25, 50, 75, 100].map(
                  (v) => (
                    <line
                      key={v}
                      x1="0"
                      y1={
                        H -
                        (v / 100) * H
                      }
                      x2={W}
                      y2={
                        H -
                        (v / 100) * H
                      }
                      className="chart-grid-line"
                    />
                  )
                )}

                <polygon
                  points={`0,${H} ${points} ${W},${H}`}
                  className="chart-area redesigned-chart-area"
                />

                <polyline
                  points={points}
                  className="chart-line redesigned-chart-line"
                />

                {chartData.map(
                  (x, i) => (
                    <circle
                      key={x.date}
                      cx={
                        chartData.length === 1
                          ? W / 2
                          : (i /
                              (chartData.length -
                                1)) *
                            W
                      }
                      cy={
                        H -
                        (x.amount / max) *
                          H
                      }
                      r="5"
                      className="chart-point"
                    />
                  )
                )}

              </svg>

            )}

          </div>

          <div className="chart-dates">
            {chartData.map((x) => (
              <span key={x.date}>
                {new Date(
                  x.date
                ).toLocaleDateString(
                  "en-US",
                  {
                    month: "short",
                    day: "numeric",
                  }
                )}
              </span>
            ))}
          </div>

        </article>

        {/* CATEGORY */}
        <article className="dashboard-panel category-panel">

          <div className="dashboard-panel-heading compact-heading">

            <div>

              <p className="panel-label">
                WHERE IT GOES
              </p>

              <h2>
                Spending by Category
              </h2>

            </div>

          </div>

          {categoryData.length === 0 ? (

            <div className="category-empty">

              <div className="category-empty-ring">
                ◌
              </div>

              <p>
                No spending categories yet.
              </p>

            </div>

          ) : (

            <div className="category-bars">

              {categoryData.map(
                (x, i) => (

                  <div
                    className="category-bar-item"
                    key={x.name}
                  >

                    <div>
                      <strong>
                        {x.name}
                      </strong>

                      <span>
                        {formatAmount(
                          x.amount
                        )}
                      </span>
                    </div>

                    <div className="category-track">

                      <div
                        className={`category-fill fill-${i}`}
                        style={{
                          width: `${x.percent}%`,
                        }}
                      />

                    </div>

                    <small>
                      {Math.round(
                        x.percent
                      )}
                      % of spending
                    </small>

                  </div>

                )
              )}

            </div>

          )}

        </article>

      </div>

      {/* LOWER DASHBOARD */}
      <div className="dashboard-lower-grid">

        {/* RECENT TRANSACTIONS */}
        <article className="dashboard-panel dashboard-transactions-panel">

          <div className="dashboard-panel-heading">

            <div>

              <p className="panel-label">
                LATEST ACTIVITY
              </p>

              <h2>
                Recent Transactions
              </h2>

              <p>
                Your most recent income
                and expenses.
              </p>

            </div>

          </div>

          <div className="transaction-list">

            {loading ? (

              <p className="no-transactions">
                Loading transactions...
              </p>

            ) : transactions.length === 0 ? (

              <p className="no-transactions">
                No transactions yet.
              </p>

            ) : (

              transactions.map((t) => (

                <div
                  className="transaction-row dashboard-transaction-row"
                  key={t.id}
                >

                  <div
                    className={`transaction-icon ${t.type}`}
                  >
                    {t.type === "income"
                      ? "↗"
                      : "↘"}
                  </div>

                  <div className="transaction-info">

                    <strong>
                      {t.name}
                    </strong>

                    <span>
                      {formatDate(
                        t.date
                      )}
                    </span>

                  </div>

                  <strong
                    className={`transaction-amount ${t.type}`}
                  >
                    {t.type === "income"
                      ? "+"
                      : "-"}
                    {formatAmount(
                      t.amount
                    )}
                  </strong>

                </div>

              ))

            )}

          </div>

        </article>

        {/* RIGHT SIDE */}
        <div className="dashboard-side-stack">

          {/* BUDGET */}
          <article className="dashboard-panel budget-panel">

            <div className="budget-heading">

              <div>

                <p className="panel-label">
                  SPENDING HEALTH
                </p>

                <h2>
                  Budget Status
                </h2>

              </div>

              <strong>
                {Math.round(
                  budget
                )}
                %
              </strong>

            </div>

            <div className="budget-track">

              <div
                className="budget-fill"
                style={{
                  width: `${budget}%`,
                }}
              />

            </div>

            <p>
              {totals.income
                ? budget <= 70
                  ? "Great job — your spending is within a comfortable range."
                  : budget <= 90
                  ? "You're approaching your income limit. Keep an eye on spending."
                  : "Spending is high compared with your recorded income."
                : "Add income to see your spending health."}
            </p>

          </article>

          {/* FINANCIAL TIP */}
          <article className="dashboard-panel tip-panel">

            <div className="tip-icon">
              ✦
            </div>

            <div>

              <p className="panel-label">
                FINANCIAL TIP
              </p>

              <h2>
                Small habits build
                strong finances.
              </h2>

              <p>
                Review your largest
                expense categories
                regularly and look
                for one simple place
                to save each month.
              </p>

            </div>

          </article>

        </div>

      </div>

    </section>
  );
}

export default Dashboard;