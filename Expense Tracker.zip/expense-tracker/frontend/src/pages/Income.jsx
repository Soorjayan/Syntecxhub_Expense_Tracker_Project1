import React, { useEffect, useMemo, useState } from "react";

const API_URL = "http://localhost:5000/api/income";

function Income() {
  const [income, setIncome] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [sortOrder, setSortOrder] = useState("newest");

  const [formData, setFormData] = useState({
    source: "",
    amount: "",
    date: "",
  });

  const getToken = () => localStorage.getItem("token");

  const fetchIncome = async () => {
    try {
      setLoading(true);
      setError("");

      const token = getToken();

      if (!token) {
        setError("You are not logged in.");
        return;
      }

      const response = await fetch(API_URL, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.status === 401) {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        window.location.reload();
        return;
      }

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.message || "Failed to load income");
      }

      setIncome(result.data || []);
    } catch (error) {
      console.error("Error loading income:", error);
      setError("Unable to load income data from the server.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIncome();
  }, []);

  const handleChange = (e) => {
    setFormData((previous) => ({
      ...previous,
      [e.target.name]: e.target.value,
    }));
  };

  const openAddForm = () => {
    setEditingId(null);
    setFormData({
      source: "",
      amount: "",
      date: new Date().toISOString().split("T")[0],
    });
    setShowForm(true);
  };

  const openEditForm = (item) => {
    setEditingId(item._id);
    setFormData({
      source: item.source || item.title || "",
      amount: item.amount ?? "",
      date: item.date
        ? new Date(item.date).toISOString().split("T")[0]
        : "",
    });
    setShowForm(true);
  };

  const closeForm = () => {
    setShowForm(false);
    setEditingId(null);
    setFormData({
      source: "",
      amount: "",
      date: "",
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.source || formData.amount === "" || !formData.date) {
      alert("Please fill in all fields.");
      return;
    }

    if (Number(formData.amount) < 0) {
      alert("Amount cannot be negative.");
      return;
    }

    try {
      setSaving(true);

      const token = getToken();
      const url = editingId ? `${API_URL}/${editingId}` : API_URL;

      const response = await fetch(url, {
        method: editingId ? "PUT" : "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          source: formData.source.trim(),
          amount: Number(formData.amount),
          date: formData.date,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(
          result.message ||
            `Failed to ${editingId ? "update" : "add"} income`
        );
      }

      await fetchIncome();
      closeForm();
    } catch (error) {
      console.error("Error saving income:", error);
      alert(error.message || "Unable to save income.");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this income?")) {
      return;
    }

    try {
      const response = await fetch(`${API_URL}/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${getToken()}`,
        },
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.message || "Failed to delete income");
      }

      await fetchIncome();
    } catch (error) {
      console.error("Error deleting income:", error);
      alert(error.message || "Unable to delete income.");
    }
  };

  const filteredIncome = useMemo(() => {
    let result = [...income];

    if (search.trim()) {
      const keyword = search.toLowerCase();

      result = result.filter((item) =>
        (item.source || item.title || "")
          .toLowerCase()
          .includes(keyword)
      );
    }

    result.sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();

      return sortOrder === "newest"
        ? dateB - dateA
        : dateA - dateB;
    });

    return result;
  }, [income, search, sortOrder]);

  const totalIncome = income.reduce(
    (total, item) => total + Number(item.amount || 0),
    0
  );

  const formatDate = (date) => {
    if (!date) return "-";

    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  return (
    <div className="income-page">
      <div className="page-header">
        <div>
          <h1>Income</h1>
          <p>Manage and track your income</p>
        </div>

        <button className="add-button" onClick={openAddForm}>
          + Add Income
        </button>
      </div>

      <div className="summary-card">
        <div>
          <span>Total Income</span>
          <h2>
            ${totalIncome.toLocaleString("en-US", {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </h2>
        </div>

        <div className="summary-icon income-icon">💰</div>
      </div>

      {showForm && (
        <div className="form-card">
          <div className="form-card-header">
            <h2>{editingId ? "Edit Income" : "Add New Income"}</h2>

            <button
              type="button"
              className="close-button"
              onClick={closeForm}
            >
              ×
            </button>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="form-grid">
              <div className="form-group">
                <label>Income Source</label>
                <input
                  type="text"
                  name="source"
                  placeholder="e.g. Salary, Freelance"
                  value={formData.source}
                  onChange={handleChange}
                />
              </div>

              <div className="form-group">
                <label>Amount</label>
                <input
                  type="number"
                  name="amount"
                  placeholder="Enter amount"
                  min="0"
                  step="0.01"
                  value={formData.amount}
                  onChange={handleChange}
                />
              </div>

              <div className="form-group">
                <label>Date</label>
                <input
                  type="date"
                  name="date"
                  value={formData.date}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="form-actions">
              <button
                type="button"
                className="cancel-button"
                onClick={closeForm}
              >
                Cancel
              </button>

              <button
                type="submit"
                className="save-button"
                disabled={saving}
              >
                {saving
                  ? "Saving..."
                  : editingId
                  ? "Update Income"
                  : "Add Income"}
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="list-controls">
        <div className="search-box">
          <input
            type="text"
            placeholder="Search income..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <select
          value={sortOrder}
          onChange={(e) => setSortOrder(e.target.value)}
          className="sort-select"
        >
          <option value="newest">Newest First</option>
          <option value="oldest">Oldest First</option>
        </select>
      </div>

      <div className="transactions-card">
        <div className="transactions-header">
          <div>
            <h2>Income History</h2>
            <p>
              {filteredIncome.length} record
              {filteredIncome.length !== 1 ? "s" : ""}
            </p>
          </div>
        </div>

        {loading ? (
          <div className="empty-state">
            <p>Loading income...</p>
          </div>
        ) : error ? (
          <div className="empty-state">
            <p>{error}</p>
            <button className="retry-button" onClick={fetchIncome}>
              Try Again
            </button>
          </div>
        ) : filteredIncome.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">💰</div>
            <h3>{search ? "No income found" : "No income yet"}</h3>
            <p>
              {search
                ? "Try a different search term."
                : "Add your first income to start tracking."}
            </p>

            {!search && (
              <button className="add-button" onClick={openAddForm}>
                + Add Income
              </button>
            )}
          </div>
        ) : (
          <div className="transaction-list">
            {filteredIncome.map((item) => {
              const source = item.source || item.title || "Income";

              return (
                <div className="transaction-row" key={item._id}>
                  <div className="transaction-left">
                    <div className="transaction-icon income-row-icon">
                      💰
                    </div>

                    <div className="transaction-info">
                      <h3>{source}</h3>
                      <span>{formatDate(item.date)}</span>
                    </div>
                  </div>

                  <div className="transaction-right">
                    <strong className="income-amount">
                      +$
                      {Number(item.amount || 0).toLocaleString("en-US", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                    </strong>

                    <div className="transaction-actions">
                      <button
                        className="edit-button"
                        onClick={() => openEditForm(item)}
                        title="Edit"
                      >
                        ✏️
                      </button>

                      <button
                        className="delete-button"
                        onClick={() => handleDelete(item._id)}
                        title="Delete"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

export default Income;
