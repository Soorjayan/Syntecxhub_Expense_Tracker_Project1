import { useState } from "react";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Income from "./pages/Income";
import Expense from "./pages/Expense";
import Profile from "./pages/Profile";

function App() {
  const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem("user");
    const token = localStorage.getItem("token");
    if (savedUser && token) { try { return JSON.parse(savedUser); } catch { localStorage.removeItem("user"); localStorage.removeItem("token"); } }
    return null;
  });
  const [currentPage, setCurrentPage] = useState("dashboard");
  const handleLogin = u => { setUser(u); setCurrentPage("dashboard"); };
  const handleProfileUpdated = u => { setUser(u); localStorage.setItem("user", JSON.stringify(u)); };
  const handleLogout = () => { localStorage.removeItem("token"); localStorage.removeItem("user"); setUser(null); setCurrentPage("dashboard"); };
  if (!user && window.location.pathname === "/signup") return <Register />;
  if (!user) return <Login onLogin={handleLogin} />;
  const renderPage = () =>
  currentPage === "income"
    ? <Income />
    : currentPage === "expense"
    ? <Expense />
    : currentPage === "profile"
    ? <Profile user={user} onProfileUpdated={handleProfileUpdated} />
    : <Dashboard onNavigateToProfile={() => setCurrentPage("profile")} />;
  const initial = user.fullName ? user.fullName.charAt(0).toUpperCase() : "U";
  return <div className="app-layout">
    <aside className="sidebar redesigned-sidebar">
      <div className="sidebar-brand"><div className="brand-mark"><span>💰</span></div><div><h2>Expense Tracker</h2><small>Smart money management</small></div></div>
      <div className="sidebar-section-label">MAIN MENU</div>
      <nav className="sidebar-nav">
        <button className={currentPage==="dashboard"?"nav-item active":"nav-item"} onClick={()=>setCurrentPage("dashboard")}><span className="nav-icon">⌂</span><span>Dashboard</span></button>
        <button className={currentPage==="income"?"nav-item active":"nav-item"} onClick={()=>setCurrentPage("income")}><span className="nav-icon">↗</span><span>Income</span></button>
        <button className={currentPage==="expense"?"nav-item active":"nav-item"} onClick={()=>setCurrentPage("expense")}><span className="nav-icon">↘</span><span>Expenses</span></button>
        <button className={currentPage==="profile"?"nav-item active":"nav-item"} onClick={()=>setCurrentPage("profile")}><span className="nav-icon">◯</span><span>Profile</span></button>
      </nav>
      <div className="sidebar-bottom redesigned-sidebar-bottom">
        <div className="sidebar-finance-note"><span>✦</span><div><strong>Stay on track</strong><small>Build better money habits.</small></div></div>
        <button className="sidebar-user sidebar-user-button" onClick={()=>setCurrentPage("profile")}><div className="user-avatar">{user.profilePhoto?<img src={user.profilePhoto} alt="Profile"/>:initial}</div><div><strong>{user.fullName||"User"}</strong><span>{user.email||""}</span></div></button>
        <button className="logout-button" onClick={handleLogout}><span>↪</span>Logout</button>
      </div>
    </aside>
    <main className="main-content">{renderPage()}</main>
  </div>;
}
export default App;
