import { NavLink } from "react-router-dom";

function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="profile">
        <div className="profile-avatar">👨‍💻</div>
        <h3>Mike William</h3>
      </div>

      <nav className="sidebar-nav">
        <NavLink to="/" className="nav-item">
          🏠 <span>Dashboard</span>
        </NavLink>

        <NavLink to="/income" className="nav-item">
          💰 <span>Income</span>
        </NavLink>

        <NavLink to="/expense" className="nav-item">
          💸 <span>Expense</span>
        </NavLink>

        <button className="nav-item logout">
          ↪ <span>Logout</span>
        </button>
      </nav>
    </aside>
  );
}

export default Sidebar;
