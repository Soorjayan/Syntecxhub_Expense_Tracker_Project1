const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const connectDB = require("./db");

const User = require("./models/User");
const Income = require("./models/Income");
const Expense = require("./models/Expense");

const authMiddleware = require("./middleware/authMiddleware");

const app = express();
const PORT = process.env.PORT || 5000;

connectDB();

app.use(cors());
app.use(express.json({ limit: "5mb" }));

/* =====================================================
   HEALTH CHECK
===================================================== */

app.get("/api/health", (req, res) => {
  res.json({
    success: true,
    message: "Expense Tracker API is running",
  });
});

/* =====================================================
   AUTHENTICATION
===================================================== */

/* ---------------- REGISTER ---------------- */

app.post("/api/auth/register", async (req, res) => {
  try {
    const {
      fullName,
      email,
      password,
      confirmPassword,
      profilePhoto,
    } = req.body;

    if (!fullName || !email || !password) {
      return res.status(400).json({
        success: false,
        message:
          "Please provide full name, email and password",
      });
    }

    if (
      confirmPassword &&
      password !== confirmPassword
    ) {
      return res.status(400).json({
        success: false,
        message: "Passwords do not match",
      });
    }

    const existingUser = await User.findOne({
      email: email.toLowerCase().trim(),
    });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message:
          "An account with this email already exists",
      });
    }

    const hashedPassword = await bcrypt.hash(
      password,
      10
    );

    const user = await User.create({
      fullName: fullName.trim(),
      email: email.toLowerCase().trim(),
      password: hashedPassword,
      profilePhoto: profilePhoto || "",
    });

    res.status(201).json({
      success: true,
      message: "Registration successful",
      data: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
        profilePhoto: user.profilePhoto,
      },
    });
  } catch (error) {
    console.error("Registration error:", error);

    res.status(500).json({
      success: false,
      message: "Registration failed",
    });
  }
});

/* ---------------- LOGIN ---------------- */

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Please enter email and password",
      });
    }

    const user = await User.findOne({
      email: email.toLowerCase().trim(),
    });

    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password",
      });
    }

    const passwordMatch = await bcrypt.compare(
      password,
      user.password
    );

    if (!passwordMatch) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password",
      });
    }

    const token = jwt.sign(
      {
        id: user._id.toString(),
        email: user.email,
      },
      process.env.JWT_SECRET,
      {
        expiresIn: "7d",
      }
    );

    res.json({
      success: true,
      message: "Login successful",
      token,
      data: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
        profilePhoto: user.profilePhoto,
      },
    });
  } catch (error) {
    console.error("Login error:", error);

    res.status(500).json({
      success: false,
      message: "Login failed",
    });
  }
});

/* =====================================================
   USER PROFILE
===================================================== */

/* ---------------- GET CURRENT PROFILE ---------------- */

app.get(
  "/api/auth/me",
  authMiddleware,
  async (req, res) => {
    try {
      const user = await User.findById(
        req.user.id
      ).select("-password");

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found",
        });
      }

      res.json({
        success: true,
        data: user,
      });
    } catch (error) {
      console.error(
        "Get profile error:",
        error
      );

      res.status(500).json({
        success: false,
        message: "Failed to get user profile",
      });
    }
  }
);

/* ---------------- UPDATE PROFILE ---------------- */

app.put(
  "/api/auth/profile",
  authMiddleware,
  async (req, res) => {
    try {
      const {
        fullName,
        profilePhoto,
      } = req.body;

      /* Validate full name */
      if (
        !fullName ||
        !fullName.trim()
      ) {
        return res.status(400).json({
          success: false,
          message: "Full name is required",
        });
      }

      /* Validate profile photo */
      if (
        profilePhoto &&
        profilePhoto.length >
          5 * 1024 * 1024
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Profile photo is too large",
        });
      }

      /* Find and update logged-in user */
      const updatedUser =
        await User.findByIdAndUpdate(
          req.user.id,
          {
            fullName: fullName.trim(),
            profilePhoto:
              profilePhoto || "",
          },
          {
            new: true,
            runValidators: true,
          }
        ).select("-password");

      if (!updatedUser) {
        return res.status(404).json({
          success: false,
          message: "User not found",
        });
      }

      res.json({
        success: true,
        message:
          "Profile updated successfully",
        data: updatedUser,
      });
    } catch (error) {
      console.error(
        "Update profile error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to update profile",
      });
    }
  }
);

/* =====================================================
   INCOME API
===================================================== */

/* ---------------- GET INCOME ---------------- */

app.get(
  "/api/income",
  authMiddleware,
  async (req, res) => {
    try {
      const income = await Income.find({
        userId: req.user.id,
      }).sort({
        date: -1,
        createdAt: -1,
      });

      res.json({
        success: true,
        data: income,
      });
    } catch (error) {
      console.error(
        "Get income error:",
        error
      );

      res.status(500).json({
        success: false,
        message: "Failed to get income",
      });
    }
  }
);

/* ---------------- ADD INCOME ---------------- */

app.post(
  "/api/income",
  authMiddleware,
  async (req, res) => {
    try {
      const {
        source,
        amount,
        date,
      } = req.body;

      if (
        !source ||
        amount === undefined ||
        amount === null ||
        amount === "" ||
        !date
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Please provide source, amount and date",
        });
      }

      if (Number(amount) < 0) {
        return res.status(400).json({
          success: false,
          message:
            "Amount cannot be negative",
        });
      }

      const newIncome =
        await Income.create({
          userId: req.user.id,
          source: source.trim(),
          amount: Number(amount),
          date,
        });

      res.status(201).json({
        success: true,
        data: newIncome,
      });
    } catch (error) {
      console.error(
        "Add income error:",
        error
      );

      res.status(500).json({
        success: false,
        message: "Failed to add income",
      });
    }
  }
);

/* ---------------- EDIT INCOME ---------------- */

app.put(
  "/api/income/:id",
  authMiddleware,
  async (req, res) => {
    try {
      const {
        source,
        amount,
        date,
      } = req.body;

      if (
        !source ||
        amount === undefined ||
        amount === null ||
        amount === "" ||
        !date
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Please provide source, amount and date",
        });
      }

      if (Number(amount) < 0) {
        return res.status(400).json({
          success: false,
          message:
            "Amount cannot be negative",
        });
      }

      const updatedIncome =
        await Income.findOneAndUpdate(
          {
            _id: req.params.id,
            userId: req.user.id,
          },
          {
            source: source.trim(),
            amount: Number(amount),
            date,
          },
          {
            new: true,
            runValidators: true,
          }
        );

      if (!updatedIncome) {
        return res.status(404).json({
          success: false,
          message: "Income not found",
        });
      }

      res.json({
        success: true,
        message:
          "Income updated successfully",
        data: updatedIncome,
      });
    } catch (error) {
      console.error(
        "Update income error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to update income",
      });
    }
  }
);

/* ---------------- DELETE INCOME ---------------- */

app.delete(
  "/api/income/:id",
  authMiddleware,
  async (req, res) => {
    try {
      const deletedIncome =
        await Income.findOneAndDelete({
          _id: req.params.id,
          userId: req.user.id,
        });

      if (!deletedIncome) {
        return res.status(404).json({
          success: false,
          message: "Income not found",
        });
      }

      res.json({
        success: true,
        message:
          "Income deleted successfully",
      });
    } catch (error) {
      console.error(
        "Delete income error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to delete income",
      });
    }
  }
);

/* =====================================================
   EXPENSE API
===================================================== */

/* ---------------- GET EXPENSES ---------------- */

app.get(
  "/api/expenses",
  authMiddleware,
  async (req, res) => {
    try {
      const expenses =
        await Expense.find({
          userId: req.user.id,
        }).sort({
          date: -1,
          createdAt: -1,
        });

      const formattedExpenses =
        expenses.map((expense) => ({
          id: expense._id,
          _id: expense._id,
          title: expense.category,
          category: expense.category,
          amount: expense.amount,
          date: expense.date,
          createdAt:
            expense.createdAt,
          updatedAt:
            expense.updatedAt,
        }));

      res.json({
        success: true,
        data: formattedExpenses,
      });
    } catch (error) {
      console.error(
        "Get expenses error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to get expenses",
      });
    }
  }
);

/* ---------------- ADD EXPENSE ---------------- */

app.post(
  "/api/expenses",
  authMiddleware,
  async (req, res) => {
    try {
      const {
        title,
        category,
        amount,
        date,
      } = req.body;

      const expenseCategory =
        category || title;

      if (
        !expenseCategory ||
        amount === undefined ||
        amount === null ||
        amount === "" ||
        !date
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Please provide title/category, amount and date",
        });
      }

      if (Number(amount) < 0) {
        return res.status(400).json({
          success: false,
          message:
            "Amount cannot be negative",
        });
      }

      const newExpense =
        await Expense.create({
          userId: req.user.id,
          category:
            expenseCategory.trim(),
          amount: Number(amount),
          date,
        });

      res.status(201).json({
        success: true,
        data: {
          id: newExpense._id,
          _id: newExpense._id,
          title: newExpense.category,
          category:
            newExpense.category,
          amount: newExpense.amount,
          date: newExpense.date,
          createdAt:
            newExpense.createdAt,
          updatedAt:
            newExpense.updatedAt,
        },
      });
    } catch (error) {
      console.error(
        "Add expense error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to add expense",
      });
    }
  }
);

/* ---------------- EDIT EXPENSE ---------------- */

app.put(
  "/api/expenses/:id",
  authMiddleware,
  async (req, res) => {
    try {
      const {
        title,
        category,
        amount,
        date,
      } = req.body;

      const expenseCategory =
        category || title;

      if (
        !expenseCategory ||
        amount === undefined ||
        amount === null ||
        amount === "" ||
        !date
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Please provide title/category, amount and date",
        });
      }

      if (Number(amount) < 0) {
        return res.status(400).json({
          success: false,
          message:
            "Amount cannot be negative",
        });
      }

      const updatedExpense =
        await Expense.findOneAndUpdate(
          {
            _id: req.params.id,
            userId: req.user.id,
          },
          {
            category:
              expenseCategory.trim(),
            amount: Number(amount),
            date,
          },
          {
            new: true,
            runValidators: true,
          }
        );

      if (!updatedExpense) {
        return res.status(404).json({
          success: false,
          message:
            "Expense not found",
        });
      }

      res.json({
        success: true,
        message:
          "Expense updated successfully",
        data: {
          id: updatedExpense._id,
          _id: updatedExpense._id,
          title:
            updatedExpense.category,
          category:
            updatedExpense.category,
          amount:
            updatedExpense.amount,
          date: updatedExpense.date,
          createdAt:
            updatedExpense.createdAt,
          updatedAt:
            updatedExpense.updatedAt,
        },
      });
    } catch (error) {
      console.error(
        "Update expense error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to update expense",
      });
    }
  }
);

/* ---------------- DELETE EXPENSE ---------------- */

app.delete(
  "/api/expenses/:id",
  authMiddleware,
  async (req, res) => {
    try {
      const deletedExpense =
        await Expense.findOneAndDelete({
          _id: req.params.id,
          userId: req.user.id,
        });

      if (!deletedExpense) {
        return res.status(404).json({
          success: false,
          message:
            "Expense not found",
        });
      }

      res.json({
        success: true,
        message:
          "Expense deleted successfully",
      });
    } catch (error) {
      console.error(
        "Delete expense error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to delete expense",
      });
    }
  }
);

/* =====================================================
   DASHBOARD API
===================================================== */

app.get(
  "/api/dashboard",
  authMiddleware,
  async (req, res) => {
    try {
      const income =
        await Income.find({
          userId: req.user.id,
        }).sort({
          date: -1,
        });

      const expenses =
        await Expense.find({
          userId: req.user.id,
        }).sort({
          date: -1,
        });

      const totalIncome =
        income.reduce(
          (total, item) =>
            total + Number(item.amount),
          0
        );

      const totalExpenses =
        expenses.reduce(
          (total, item) =>
            total + Number(item.amount),
          0
        );

      const balance =
        totalIncome - totalExpenses;

      const recentTransactions = [
        ...income.map((item) => ({
          id: item._id,
          type: "income",
          title: item.source,
          amount: item.amount,
          date: item.date,
        })),

        ...expenses.map((item) => ({
          id: item._id,
          type: "expense",
          title: item.category,
          amount: item.amount,
          date: item.date,
        })),
      ]
        .sort(
          (a, b) =>
            new Date(b.date) -
            new Date(a.date)
        )
        .slice(0, 10);

      res.json({
        success: true,
        data: {
          totalIncome,
          totalExpenses,
          balance,
          recentTransactions,
        },
      });
    } catch (error) {
      console.error(
        "Dashboard error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to load dashboard data",
      });
    }
  }
);

/* =====================================================
   START SERVER
===================================================== */

app.listen(PORT, () => {
  console.log(
    `Backend server running on http://localhost:${PORT}`
  );
});