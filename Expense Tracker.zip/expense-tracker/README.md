# Expense Tracker

Our own full-stack Expense Tracker implementation based on the supplied UI screenshots as functional/UI references.

## Structure
- frontend — React + Vite
- backend — Node.js + Express

## Run frontend
cd frontend
npm install
npm run dev

## Run backend (second terminal)
cd backend
npm install
npm run dev

Backend health check: http://localhost:5000/api/health

## Build roadmap
1. Project setup
2. Frontend layout/components
3. Dashboard
4. Income management
5. Expense management
6. Add Expense modal
7. Edit/Delete
8. Charts/calculations
9. Download/export
10. MongoDB
11. Authentication
12. Responsive UI
13. Testing/polish
